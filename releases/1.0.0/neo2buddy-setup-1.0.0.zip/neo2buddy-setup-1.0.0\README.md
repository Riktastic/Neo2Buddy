﻿# Neo2 Buddy Setup 1.0.0

Install firmware on your ESP32-S3 buddy board â€” **no ESP-IDF** needed.

## Windows

1. Install [Python 3.10+](https://www.python.org/downloads/) if needed (tick **Add python.exe to PATH**).
2. Double-click `Run Setup.bat`.
3. Plug the boardâ€™s **programming / UART** USB cable into the PC.
4. Select the COM port â†’ **Install firmware**.

## macOS / Linux

```
cd neo2buddy-setup-1.0.0
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python -m neo2buddy_flasher
```

## Tips

- Use the programming USB port (CH340 / UART), not the Neo OTG host port.
- If install fails: Advanced â†’ **Hold buttons before install**, then hold BOOT, tap RESET, release BOOT, Install.
- Project page: https://github.com/Riktastic/Neo2Buddy
- After install, join the buddy Wiâ€‘Fi and open the portal (fresh SoftAP: http://192.168.4.1/).
